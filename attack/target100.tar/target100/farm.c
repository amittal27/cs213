/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

void setval_156(unsigned *p)
{
    *p = 2462550344U;
}

unsigned getval_113()
{
    return 2425393240U;
}

unsigned addval_409(unsigned x)
{
    return x + 3351742792U;
}

unsigned addval_436(unsigned x)
{
    return x + 3344472014U;
}

unsigned addval_364(unsigned x)
{
    return x + 3284633928U;
}

void setval_190(unsigned *p)
{
    *p = 3284633928U;
}

void setval_111(unsigned *p)
{
    *p = 1488408918U;
}

unsigned addval_367(unsigned x)
{
    return x + 1358762930U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_429(unsigned *p)
{
    *p = 2425411209U;
}

unsigned addval_480(unsigned x)
{
    return x + 3767093357U;
}

unsigned getval_346()
{
    return 2425670281U;
}

unsigned getval_390()
{
    return 3682912937U;
}

unsigned getval_159()
{
    return 3224945033U;
}

unsigned addval_342(unsigned x)
{
    return x + 3532966537U;
}

void setval_101(unsigned *p)
{
    *p = 3229139337U;
}

unsigned addval_370(unsigned x)
{
    return x + 3523789209U;
}

unsigned getval_237()
{
    return 3680551305U;
}

void setval_274(unsigned *p)
{
    *p = 3251178861U;
}

unsigned getval_204()
{
    return 3281046153U;
}

void setval_313(unsigned *p)
{
    *p = 3536115337U;
}

void setval_394(unsigned *p)
{
    *p = 3677932171U;
}

unsigned getval_415()
{
    return 3385115017U;
}

unsigned addval_173(unsigned x)
{
    return x + 3767093472U;
}

void setval_478(unsigned *p)
{
    *p = 3286272360U;
}

unsigned addval_416(unsigned x)
{
    return x + 3229931137U;
}

unsigned getval_112()
{
    return 2425476745U;
}

unsigned getval_186()
{
    return 3281043849U;
}

unsigned addval_336(unsigned x)
{
    return x + 3674789517U;
}

void setval_385(unsigned *p)
{
    *p = 3353381192U;
}

unsigned getval_286()
{
    return 3599350497U;
}

unsigned getval_264()
{
    return 3769190586U;
}

unsigned getval_304()
{
    return 3525364361U;
}

void setval_153(unsigned *p)
{
    *p = 3269495112U;
}

unsigned getval_209()
{
    return 3380926081U;
}

unsigned getval_477()
{
    return 3234120073U;
}

unsigned addval_361(unsigned x)
{
    return x + 3286272330U;
}

void setval_495(unsigned *p)
{
    *p = 3281180297U;
}

void setval_407(unsigned *p)
{
    *p = 3770796681U;
}

unsigned getval_302()
{
    return 3286288712U;
}

unsigned addval_151(unsigned x)
{
    return x + 3281046217U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
